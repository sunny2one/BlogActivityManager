package com.sunny2one.blogactivitymanager

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sunny2one.blogactivitymanager.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("blog_activity_manager", MODE_PRIVATE) }

    private var timer: CountDownTimer? = null
    private var remainingMs = DEFAULT_DURATION_MS
    private var isRunning = false

    private var likeCount = 0
    private var commentCount = 0
    private var skipCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadState()
        updateTimerText()
        updateStats()

        binding.saveButton.setOnClickListener { saveInputs() }
        binding.copyButton.setOnClickListener { copyComment() }
        binding.openNaverButton.setOnClickListener { openNaverBlog() }
        binding.startButton.setOnClickListener { startTimer() }
        binding.pauseButton.setOnClickListener { pauseTimer() }
        binding.resetButton.setOnClickListener { resetTimer() }

        binding.likeDoneButton.setOnClickListener {
            likeCount++
            record("좋아요 완료")
            saveCounters()
            updateStats()
        }

        binding.commentDoneButton.setOnClickListener {
            commentCount++
            record("댓글 완료")
            saveCounters()
            updateStats()
        }

        binding.skipButton.setOnClickListener {
            skipCount++
            record("건너뜀")
            saveCounters()
            updateStats()
        }
    }

    override fun onPause() {
        super.onPause()
        saveInputs()
        saveCounters()
        prefs.edit().putLong("remaining_ms", remainingMs).apply()
    }

    private fun saveInputs() {
        prefs.edit()
            .putString("keyword", binding.keywordInput.text.toString())
            .putString("comment", binding.commentInput.text.toString())
            .apply()
        Toast.makeText(this, "저장했습니다.", Toast.LENGTH_SHORT).show()
    }

    private fun loadState() {
        binding.keywordInput.setText(prefs.getString("keyword", ""))
        binding.commentInput.setText(prefs.getString("comment", ""))
        remainingMs = prefs.getLong("remaining_ms", DEFAULT_DURATION_MS)
        likeCount = prefs.getInt("like_count", 0)
        commentCount = prefs.getInt("comment_count", 0)
        skipCount = prefs.getInt("skip_count", 0)
    }

    private fun copyComment() {
        val text = binding.commentInput.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "댓글 문구를 먼저 입력해주세요.", Toast.LENGTH_SHORT).show()
            return
        }

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("blog_comment", text))
        record("댓글 복사")
        Toast.makeText(this, "댓글을 복사했습니다.", Toast.LENGTH_SHORT).show()
    }

    private fun openNaverBlog() {
        val packageName = "com.nhn.android.blog"
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)

        if (launchIntent != null) {
            record("네이버 블로그 앱 열기")
            startActivity(launchIntent)
            return
        }

        Toast.makeText(this, "네이버 블로그 앱이 설치되어 있지 않습니다.", Toast.LENGTH_LONG).show()
        val marketIntent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("market://details?id=$packageName")
        )
        runCatching { startActivity(marketIntent) }
    }

    private fun startTimer() {
        if (isRunning) return

        if (remainingMs <= 0L) remainingMs = DEFAULT_DURATION_MS
        isRunning = true
        binding.statusText.text = "상태: 작업 중"

        timer = object : CountDownTimer(remainingMs, 1_000L) {
            override fun onTick(millisUntilFinished: Long) {
                remainingMs = millisUntilFinished
                updateTimerText()
            }

            override fun onFinish() {
                remainingMs = 0L
                isRunning = false
                binding.statusText.text = "상태: 최소 작업시간 완료"
                updateTimerText()
                record("최소 2분 작업시간 완료")
                Toast.makeText(
                    this@MainActivity,
                    "최소 작업시간 2분이 완료되었습니다.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun pauseTimer() {
        timer?.cancel()
        isRunning = false
        binding.statusText.text = "상태: 일시정지"
        prefs.edit().putLong("remaining_ms", remainingMs).apply()
    }

    private fun resetTimer() {
        timer?.cancel()
        isRunning = false
        remainingMs = DEFAULT_DURATION_MS
        binding.statusText.text = "상태: 대기 중"
        updateTimerText()
        prefs.edit().putLong("remaining_ms", remainingMs).apply()
    }

    private fun updateTimerText() {
        val totalSeconds = (remainingMs / 1_000L).coerceAtLeast(0L)
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        binding.timerText.text = String.format(Locale.KOREA, "%02d:%02d", minutes, seconds)
    }

    private fun saveCounters() {
        prefs.edit()
            .putInt("like_count", likeCount)
            .putInt("comment_count", commentCount)
            .putInt("skip_count", skipCount)
            .apply()
    }

    private fun updateStats() {
        binding.statsText.text =
            "오늘 좋아요 ${likeCount}회 · 댓글 ${commentCount}회 · 건너뜀 ${skipCount}회"
    }

    private fun record(action: String) {
        val keyword = binding.keywordInput.text.toString().trim()
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA).format(Date())
        val oldLog = prefs.getString("activity_log", "").orEmpty()
        val newLine = "$timestamp | $action | $keyword"
        prefs.edit().putString("activity_log", "$newLine\n$oldLog").apply()
    }

    companion object {
        private const val DEFAULT_DURATION_MS = 120_000L
    }
}
