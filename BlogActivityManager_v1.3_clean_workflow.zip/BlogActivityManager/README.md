# Blog Activity Manager v1.3

Android Kotlin + Jetpack Compose + Room + DataStore + AccessibilityService 프로젝트입니다.

## 빌드
1. 저장소 최상단에 `.github`, `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`가 보이도록 업로드합니다.
2. GitHub `Actions` → `Build Android APK` → `Run workflow`를 누릅니다.
3. 완료 후 Artifacts의 `BlogActivityManager-v1.3`을 내려받습니다.

## 사용 전 필수
- 앱에서 키워드와 댓글 문구를 등록합니다.
- 접근성 서비스에서 Blog Activity Manager를 허용합니다.
- 처음에는 반드시 테스트 모드로 실행합니다.
- 네이버 블로그 앱 버전에 따라 접근성 노드 문자열과 검색 결과 구조가 달라질 수 있습니다. 로그를 확인해 `NaverNodeTexts.kt`와 `BlogAccessibilityService.kt`의 탐색 규칙을 조정해야 할 수 있습니다.

## 안전 동작
- 캡차, 본인인증, 이용 제한은 우회하지 않고 중지합니다.
- 댓글 등록 결과가 불확실하면 재등록하지 않고 `RESULT_UNCONFIRMED`로 남깁니다.
- 좋아요 상태를 확인할 수 없으면 반복 클릭하지 않습니다.

## 한계
접근성 서비스는 앱 화면 구조에 의존합니다. 이 프로젝트는 빌드 가능한 전체 구조와 상태 머신을 제공하지만, 실제 기기에서 네이버 앱의 노드가 노출되는 방식에 따라 검색 결과 게시글 판별과 좋아요 상태 확인을 추가 조정해야 할 수 있습니다.


## v1.2 수정사항
- 운영시간 자동 시작 알람 및 재부팅 후 재등록
- 네이버 블로그 패키지 외 화면 클릭 방지
- SKIPPED/NEEDS_REVIEW 재처리 차단
- 좋아요·댓글 개별 처리 상태 유지
- 댓글 성공 판정 및 전체 노드 제한문구 감지 보강
- 테스트 시작 버튼 분리


## v1.2 수정사항
- 완료 결과 기준 통계 집계 수정
- 작업 종료 시 Foreground Service 및 WakeLock 정리
- 댓글 처리 후 게시글 화면 복귀 보장
- 테스트 실행은 댓글 사용 횟수에서 제외
- 작업 완료 시 최신 설정을 다시 읽어 순환 위치만 갱신
- 알림 상태 실시간 갱신
- 운영 요일, 오류 동작, 네이버 자동 실행 설정 UI 추가
- Room destructive migration 제거


## v1.3 수정사항
- Foreground Service 즉시 시작 처리
- 일반 시작과 테스트 시작 실행 모드 완전 분리
- 좋아요·댓글 일일 한도 모두 도달 시 자동 종료
- 자정을 넘기는 운영시간의 전날 요일 판정 수정
- 검색 제출, 블로그 탭, 최신순 선택 성공 여부 검증
- 일시정지 시 WakeLock 해제, 재개 시 재획득
- 댓글 한도 도달 시 댓글 문구 미등록으로 인한 오중지 방지
