package com.example.blogactivitymanager.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.blogactivitymanager.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class BlogAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val db by lazy { AppDatabase.get(this) }
    private val store by lazy { SettingsStore(this) }
    @Volatile private var loopStarted = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (AutomationState.state.value.running && !loopStarted) {
            loopStarted = true
            scope.launch { runLoop() }
        }
    }
    override fun onInterrupt() = stopNow("접근성 서비스 중단")
    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private suspend fun runLoop() {
        try {
            while (AutomationState.state.value.running && !AutomationState.stopRequested) {
                waitWhilePaused()
                val settings = store.settings.first()
                if (!settings.likeEnabled && !settings.commentEnabled) return stopWith("좋아요 또는 댓글 기능을 하나 이상 활성화해주세요")
                when (scheduleState(settings)) {
                    ScheduleState.ACTIVE -> Unit
                    ScheduleState.BEFORE_START, ScheduleState.DISABLED_DAY -> {
                        update("운영시간 대기", "")
                        delay(30_000)
                        continue
                    }
                    ScheduleState.AFTER_END -> return stopWith("운영 종료시간 도달")
                }
                val today = today()
                val stats = db.dao().getDailyStats(today) ?: DailyStatsEntity(today)
                if (stats.processedCount >= settings.dailyPostLimit) return stopWith("하루 최대 게시글 수 도달")

                val canRunLike = settings.likeEnabled && stats.likeSuccessCount < settings.dailyLikeLimit
                val canRunComment = settings.commentEnabled && stats.commentSuccessCount < settings.dailyCommentLimit
                if (!canRunLike && !canRunComment) return stopWith("오늘 좋아요·댓글 작업 한도 도달")

                val keyword = nextKeyword(settings, today) ?: return stopWith("모든 키워드 목표 완료")
                val comments = if (canRunComment) db.dao().getEnabledComments() else emptyList()
                if (canRunComment && comments.isEmpty()) return stopWith("사용할 댓글 문구가 없습니다")
                val comment = chooseComment(comments, settings)

                val started = System.currentTimeMillis()
                val target = Random.nextInt(settings.minSeconds, settings.maxSeconds + 1)
                AutomationState.state.value = AutomationState.state.value.copy(currentKeyword = keyword.keyword, todayGoal = settings.dailyPostLimit)

                if (!navigateToSearch(keyword.keyword)) {
                    recordFailure(keyword.keyword, started, "검색 흐름 실패")
                    handleError(settings, "검색 흐름 실패")
                    continue
                }
                if (!isNaverBlogScreen()) { handleError(settings, "네이버 블로그 앱 화면이 아닙니다"); continue }
                val post = openFirstUnprocessedPost(keyword.keyword)
                if (post == null) {
                    recordFailure(keyword.keyword, started, "미처리 게시글을 찾지 못함")
                    handleError(settings, "게시글 선택 실패")
                    continue
                }
                val postId = post.first
                val postTitle = post.second
                val blogName = post.third
                if (db.dao().latestHistory(postId)?.overallResult in setOf("COMPLETE", "SKIPPED", "NEEDS_REVIEW")) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    delay(1500)
                    continue
                }

                val root = rootInActiveWindow
                if (containsAny(root, NaverNodeTexts.BLOCKED)) return stopWith("보안 또는 이용 제한 화면 감지")
                if (containsAny(root, NaverNodeTexts.PRIVATE_OR_DELETED)) {
                    saveHistory(postId, postTitle, blogName, keyword.keyword, "BUTTON_NOT_FOUND", "NOT_AVAILABLE", "SKIPPED", "비공개 또는 삭제", started, settings.testMode)
                    finishPost(keyword, stats, "BUTTON_NOT_FOUND", "NOT_AVAILABLE", "SKIPPED")
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    continue
                }

                val previous = db.dao().latestHistory(postId)
                val effectiveTestMode = AutomationState.testRunOverride
                val runSettings = settings.copy(testMode = effectiveTestMode)
                val likeHandled = previous?.likeResult in setOf("SUCCESS", "ALREADY_LIKED")
                val commentHandled = previous?.commentResult in setOf("SUCCESS", "RESULT_UNCONFIRMED")
                val likeResult = when {
                    !canRunLike -> "DISABLED"
                    likeHandled -> previous?.likeResult ?: "DISABLED"
                    else -> processLike(runSettings)
                }
                val commentResult = when {
                    !canRunComment -> "DISABLED"
                    commentHandled -> previous?.commentResult ?: "DISABLED"
                    else -> processComment(runSettings, comment?.content.orEmpty())
                }
                val overall = resultOf(likeResult, commentResult)

                waitUntilTarget(started, target)
                saveHistory(postId, postTitle, blogName, keyword.keyword, likeResult, commentResult, overall, "", started, effectiveTestMode, comment?.content.orEmpty())
                finishPost(keyword, stats, likeResult, commentResult, overall)
                if (comment != null && commentResult == "SUCCESS") {
                    db.dao().updateComment(comment.copy(useCount = comment.useCount + 1, lastUsedAt = System.currentTimeMillis()))
                }
                performGlobalAction(GLOBAL_ACTION_BACK)
                delay(2000)

                if (settings.restEnabled && AutomationState.state.value.todayProcessed > 0 && AutomationState.state.value.todayProcessed % settings.restEvery == 0) {
                    val minutes = Random.nextInt(settings.restMinMinutes, settings.restMaxMinutes + 1)
                    update("휴식 ${minutes}분", keyword.keyword)
                    safeDelay(minutes * 60L)
                }
                if (scheduleState(settings) != ScheduleState.ACTIVE || AutomationState.finishCurrentThenStop) return stopWith("현재 게시글 완료 후 운영 종료")
            }
        } catch (t: Throwable) {
            log("ERROR", "LOOP", t.message ?: t.javaClass.simpleName)
            stopWith("오류로 중지")
        } finally { loopStarted = false }
    }

    private suspend fun navigateToSearch(keyword: String): Boolean {
        update("검색 버튼 탐색", keyword)
        val search = waitNode(NaverNodeTexts.SEARCH, 3) ?: return false
        if (!clickNode(search)) return false
        delay(1000)

        val input = waitEditableOrText(NaverNodeTexts.SEARCH_INPUT, 3) ?: return false
        if (!setText(input, keyword)) return false

        val submitted = input.performAction(AccessibilityNodeInfo.ACTION_IME_ENTER)
        if (!submitted) {
            val submitButton = waitNode(NaverNodeTexts.SEARCH_SUBMIT, 2) ?: return false
            if (!clickNode(submitButton)) return false
        }
        delay(Random.nextLong(3_000, 10_001))

        val blogTab = waitNode(NaverNodeTexts.BLOG_TAB, 4) ?: return false
        if (!clickNode(blogTab)) return false
        delay(1200)

        val latest = waitNode(NaverNodeTexts.LATEST, 4) ?: return false
        if (!clickNode(latest)) return false
        delay(Random.nextLong(3_000, 10_001))

        return isNaverBlogScreen() && containsAny(rootInActiveWindow, NaverNodeTexts.BLOG_TAB + NaverNodeTexts.LATEST)
    }

    private suspend fun openFirstUnprocessedPost(keyword: String): Triple<String,String,String>? {
        update("미처리 게시글 선택", keyword)
        val root = rootInActiveWindow ?: return null
        val candidates = clickableTextNodes(root).filter { isLikelyPostCandidate(it) }
        for (node in candidates.take(20)) {
            val title = nodeText(node).trim()
            if (title.length < 4) continue
            val id = sha256("$keyword|$title")
            val old = db.dao().latestHistory(id)
            if (old?.overallResult in setOf("COMPLETE", "SKIPPED", "NEEDS_REVIEW")) continue
            if (clickNode(node)) {
                delay(Random.nextLong(5_000, 15_001))
                if (isNaverBlogScreen() && containsAny(rootInActiveWindow, NaverNodeTexts.POST_SCREEN_MARKERS)) {
                    AutomationState.state.value = AutomationState.state.value.copy(currentPostTitle = title)
                    return Triple(id, title, "")
                }
                performGlobalAction(GLOBAL_ACTION_BACK)
                delay(1200)
            }
        }
        return null
    }

    private suspend fun processLike(settings: AppSettings): String {
        update("좋아요 확인", AutomationState.state.value.currentKeyword)
        val node = waitNode(NaverNodeTexts.LIKE, 2) ?: return "BUTTON_NOT_FOUND"
        val desc = nodeText(node)
        if (node.isSelected || node.isChecked || NaverNodeTexts.LIKED.any { desc.contains(it, true) }) return "ALREADY_LIKED"
        if (settings.testMode) return "TEST_ONLY"
        delay(Random.nextLong(3_000, 8_001))
        if (!clickNode(node)) return "FAILED"
        delay(Random.nextLong(2_000, 6_001))
        val after = waitNode(NaverNodeTexts.LIKE + NaverNodeTexts.LIKED, 2)
        return if (after != null && (after.isSelected || after.isChecked || NaverNodeTexts.LIKED.any { nodeText(after).contains(it, true) })) "SUCCESS" else "FAILED"
    }

    private suspend fun processComment(settings: AppSettings, text: String): String {
        update("댓글 확인", AutomationState.state.value.currentKeyword)
        val button = waitNode(NaverNodeTexts.COMMENT, 2) ?: return "NOT_AVAILABLE"
        if (!clickNode(button)) return "FAILED"
        delay(Random.nextLong(3_000, 8_001))

        val input = waitEditableOrText(NaverNodeTexts.COMMENT_INPUT, 3)
        if (input == null) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            delay(800)
            return "INPUT_NOT_FOUND"
        }
        if (text.isBlank() || !setText(input, text)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            delay(800)
            return "INPUT_NOT_FOUND"
        }

        delay(Random.nextLong(10_000, 25_001))
        val register = waitNode(NaverNodeTexts.REGISTER, 3)
        if (register == null) {
            setText(input, "")
            performGlobalAction(GLOBAL_ACTION_BACK)
            delay(800)
            return "REGISTER_NOT_FOUND"
        }
        if (settings.testMode) {
            setText(input, "")
            performGlobalAction(GLOBAL_ACTION_BACK)
            delay(1_000)
            return "TEST_ONLY"
        }
        if (!register.isEnabled || !clickNode(register)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            delay(800)
            return "FAILED"
        }

        delay(Random.nextLong(5_000, 15_001))
        val root = rootInActiveWindow
        val editableAfter = findEditable(root)
        val inputCleared = editableAfter != null && editableAfter.text?.toString().orEmpty().isBlank()
        val writtenCommentFound = containsExactText(root, text)
        val confirmed = containsAny(root, NaverNodeTexts.COMMENT_SUCCESS) || inputCleared || writtenCommentFound

        performGlobalAction(GLOBAL_ACTION_BACK)
        delay(1_000)
        return if (confirmed) "SUCCESS" else "RESULT_UNCONFIRMED"
    }

    private suspend fun nextKeyword(settings: AppSettings, date: String): KeywordEntity? {
        val all = db.dao().getKeywords().filter { it.enabled }
        if (all.isEmpty()) return null
        val normalized = all.map {
            if (it.lastCountDate != date) {
                val reset = it.copy(todayCount = 0, lastCountDate = date, updatedAt = System.currentTimeMillis())
                db.dao().updateKeyword(reset); reset
            } else it
        }
        val eligible = normalized.filter { it.todayCount < it.dailyTarget }
        if (eligible.isEmpty()) return null
        val idx = settings.currentKeywordIndex.mod(eligible.size)
        return eligible[idx]
    }

    private suspend fun chooseComment(comments: List<CommentTemplateEntity>, settings: AppSettings): CommentTemplateEntity? {
        if (comments.isEmpty()) return null
        return if (settings.commentMode == "RANDOM") comments.random() else comments[settings.currentCommentIndex.mod(comments.size)]
    }

    private suspend fun finishPost(
        keyword: KeywordEntity,
        stats: DailyStatsEntity,
        likeResult: String,
        commentResult: String,
        overallResult: String
    ) {
        val updatedKeyword = keyword.copy(
            todayCount = keyword.todayCount + 1,
            lastCountDate = today(),
            updatedAt = System.currentTimeMillis()
        )
        db.dao().updateKeyword(updatedKeyword)

        val updatedStats = stats.copy(
            processedCount = stats.processedCount + 1,
            likeSuccessCount = stats.likeSuccessCount + if (likeResult == "SUCCESS") 1 else 0,
            commentSuccessCount = stats.commentSuccessCount + if (commentResult == "SUCCESS") 1 else 0,
            skipCount = stats.skipCount + if (overallResult == "SKIPPED") 1 else 0,
            failureCount = stats.failureCount + if (overallResult in setOf("FAILED", "NEEDS_REVIEW")) 1 else 0
        )
        db.dao().upsertDailyStats(updatedStats)

        val latestSettings = store.settings.first()
        store.save(
            latestSettings.copy(
                currentKeywordIndex = latestSettings.currentKeywordIndex + 1,
                currentCommentIndex = latestSettings.currentCommentIndex + 1
            )
        )

        val nextRestIn = if (latestSettings.restEnabled) {
            val remainder = updatedStats.processedCount % latestSettings.restEvery.coerceAtLeast(1)
            if (remainder == 0) latestSettings.restEvery else latestSettings.restEvery - remainder
        } else 0

        AutomationState.state.value = AutomationState.state.value.copy(
            todayProcessed = updatedStats.processedCount,
            likeSuccess = updatedStats.likeSuccessCount,
            commentSuccess = updatedStats.commentSuccessCount,
            skipped = updatedStats.skipCount,
            errors = updatedStats.failureCount,
            nextRestIn = nextRestIn,
            status = "게시글 처리 완료",
            elapsedSeconds = 0,
            remainingSeconds = 0
        )
    }

    private fun resultOf(like: String, comment: String): String = when {
        like == "RESULT_UNCONFIRMED" || comment == "RESULT_UNCONFIRMED" -> "NEEDS_REVIEW"
        like == "BUTTON_NOT_FOUND" && comment == "NOT_AVAILABLE" -> "SKIPPED"
        like == "FAILED" && comment == "FAILED" -> "FAILED"
        like in setOf("SUCCESS","ALREADY_LIKED","BUTTON_NOT_FOUND","DISABLED","TEST_ONLY") &&
            comment in setOf("SUCCESS","NOT_AVAILABLE","DISABLED","TEST_ONLY") -> "COMPLETE"
        else -> "PARTIAL_COMPLETE"
    }

    private suspend fun waitUntilTarget(started: Long, targetSeconds: Int) {
        while (true) {
            waitWhilePaused()
            if (AutomationState.stopRequested) return
            val elapsed = ((System.currentTimeMillis() - started) / 1000).toInt()
            val remain = targetSeconds - elapsed
            AutomationState.state.value = AutomationState.state.value.copy(elapsedSeconds = elapsed, remainingSeconds = remain.coerceAtLeast(0))
            if (remain <= 0) return
            delay(1000)
        }
    }

    private suspend fun safeDelay(seconds: Long) {
        var left = seconds
        while (left > 0 && !AutomationState.stopRequested) {
            waitWhilePaused(); delay(1000); left--
        }
    }

    private suspend fun waitWhilePaused() {
        while (AutomationState.pauseRequested && !AutomationState.stopRequested) {
            AutomationState.state.value = AutomationState.state.value.copy(paused = true, status = "일시정지")
            delay(500)
        }
        if (!AutomationState.stopRequested) AutomationState.state.value = AutomationState.state.value.copy(paused = false)
    }

    private enum class ScheduleState { ACTIVE, BEFORE_START, AFTER_END, DISABLED_DAY }

    private fun scheduleState(s: AppSettings): ScheduleState {
        if (!s.scheduleEnabled) return ScheduleState.ACTIVE

        val calendar = Calendar.getInstance()
        val now = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        val start = s.startHour * 60 + s.startMinute
        val end = s.endHour * 60 + s.endMinute

        if (start == end) {
            return if (dayIndex(calendar) in s.enabledDays) ScheduleState.ACTIVE else ScheduleState.DISABLED_DAY
        }

        if (start < end) {
            if (dayIndex(calendar) !in s.enabledDays) return ScheduleState.DISABLED_DAY
            return when {
                now < start -> ScheduleState.BEFORE_START
                now >= end -> ScheduleState.AFTER_END
                else -> ScheduleState.ACTIVE
            }
        }

        // 자정을 넘기는 일정: 종료시각 이전은 전날 운영요일의 연장 구간입니다.
        if (now >= start) {
            return if (dayIndex(calendar) in s.enabledDays) ScheduleState.ACTIVE else ScheduleState.DISABLED_DAY
        }
        if (now < end) {
            val previousDay = calendar.clone() as Calendar
            previousDay.add(Calendar.DAY_OF_YEAR, -1)
            return if (dayIndex(previousDay) in s.enabledDays) ScheduleState.ACTIVE else ScheduleState.DISABLED_DAY
        }
        return ScheduleState.BEFORE_START
    }

    private fun dayIndex(c: Calendar): Int = when (c.get(Calendar.DAY_OF_WEEK)) {
        Calendar.MONDAY -> 1
        Calendar.TUESDAY -> 2
        Calendar.WEDNESDAY -> 3
        Calendar.THURSDAY -> 4
        Calendar.FRIDAY -> 5
        Calendar.SATURDAY -> 6
        else -> 7
    }

    private suspend fun waitNode(candidates: List<String>, tries: Int): AccessibilityNodeInfo? {
        repeat(tries) { findNode(rootInActiveWindow, candidates)?.let { return it }; delay(800) }
        return null
    }
    private suspend fun waitEditableOrText(candidates: List<String>, tries: Int): AccessibilityNodeInfo? {
        repeat(tries) { findEditable(rootInActiveWindow)?.let { return it }; findNode(rootInActiveWindow, candidates)?.let { return it }; delay(800) }
        return null
    }
    private fun findNode(root: AccessibilityNodeInfo?, candidates: List<String>): AccessibilityNodeInfo? {
        if (root == null) return null
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst(); val hay = nodeText(n)
            if (candidates.any { hay.contains(it, true) } && (n.isClickable || n.parent?.isClickable == true || n.isEditable)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let(q::add)
        }
        return null
    }
    private fun findEditable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty()) { val n=q.removeFirst(); if (n.isEditable || n.className?.toString()?.contains("EditText") == true) return n; for(i in 0 until n.childCount) n.getChild(i)?.let(q::add) }
        return null
    }
    private fun clickableTextNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>(); val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty()) { val n=q.removeFirst(); if ((n.isClickable || n.parent?.isClickable == true) && nodeText(n).isNotBlank()) out += n; for(i in 0 until n.childCount) n.getChild(i)?.let(q::add) }
        return out
    }
    private fun nodeText(n: AccessibilityNodeInfo): String = listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), n.viewIdResourceName).joinToString(" ")
    private fun allNodeText(root: AccessibilityNodeInfo): String {
        val out = StringBuilder(); val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst(); out.append(' ').append(nodeText(n))
            for (i in 0 until n.childCount) n.getChild(i)?.let(q::add)
        }
        return out.toString()
    }
    private fun containsAny(root: AccessibilityNodeInfo?, list: List<String>): Boolean {
        if (root == null) return false
        val all = allNodeText(root)
        return list.any { all.contains(it, true) }
    }
    private fun containsExactText(root: AccessibilityNodeInfo?, text: String): Boolean {
        if (root == null || text.isBlank()) return false
        return allNodeText(root).contains(text, ignoreCase = false)
    }
    private fun isNaverBlogScreen(): Boolean = rootInActiveWindow?.packageName?.toString() == NaverNodeTexts.NAVER_BLOG_PACKAGE
    private fun isLikelyPostCandidate(node: AccessibilityNodeInfo): Boolean {
        val text = nodeText(node).trim()
        if (text.length < 4 || text.length > 160) return false
        val excluded = NaverNodeTexts.RESULT_EXCLUSIONS.any { text.contains(it, true) }
        return !excluded && (node.isClickable || node.parent?.isClickable == true)
    }
    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var p=n.parent; repeat(5) { if (p?.isClickable == true) return p!!.performAction(AccessibilityNodeInfo.ACTION_CLICK); p=p?.parent }
        return false
    }
    private fun setText(n: AccessibilityNodeInfo, text: String): Boolean = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) })
    private suspend fun update(step: String, keyword: String) { AutomationState.state.value = AutomationState.state.value.copy(status="작업 중", currentStep=step, currentKeyword=keyword); log("INFO",step,step) }
    private suspend fun log(level:String, step:String, message:String) { db.dao().insertLog(AppLogEntity(level=level, step=step, message=message, keyword=AutomationState.state.value.currentKeyword)) }
    private suspend fun saveHistory(id:String,title:String,blog:String,keyword:String,like:String,comment:String,overall:String,reason:String,started:Long,test:Boolean,used:String="") { db.dao().insertHistory(PostHistoryEntity(postUniqueId=id,postTitle=title,blogName=blog,keyword=keyword,likeResult=like,commentResult=comment,overallResult=overall,failureReason=reason,processingDuration=(System.currentTimeMillis()-started)/1000,testMode=test,usedComment=used)) }
    private suspend fun recordFailure(keyword:String, started:Long, reason:String) = saveHistory(sha256("$keyword|$started"),"","",keyword,"DISABLED","DISABLED","FAILED",reason,started,false)
    private suspend fun handleError(s:AppSettings, reason:String) { log("ERROR","ERROR",reason); if (s.errorAction=="STOP") stopWith(reason) else { AutomationState.pauseRequested=true; AutomationState.state.value=AutomationState.state.value.copy(status=reason,paused=true) } }
    private suspend fun stopWith(reason: String) {
        AutomationState.stopRequested = true
        AutomationState.pauseRequested = false
        AutomationState.testRunOverride = false
        AutomationState.state.value = AutomationState.state.value.copy(running = false, paused = false, status = reason)
        log("WARNING", "STOP", reason)
        AutomationForegroundService.stop(this, reason)
    }
    private fun stopNow(reason: String) {
        AutomationState.stopRequested = true
        AutomationState.pauseRequested = false
        AutomationState.testRunOverride = false
        AutomationState.state.value = AutomationState.state.value.copy(running = false, paused = false, status = reason)
        AutomationForegroundService.stop(this, reason)
    }
    private fun sha256(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.KOREA).format(Date())
}
