package com.example.blogactivitymanager.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM keywords ORDER BY sortOrder, id") fun observeKeywords(): Flow<List<KeywordEntity>>
    @Query("SELECT * FROM keywords ORDER BY sortOrder, id") suspend fun getKeywords(): List<KeywordEntity>
    @Insert suspend fun insertKeyword(item: KeywordEntity)
    @Update suspend fun updateKeyword(item: KeywordEntity)
    @Delete suspend fun deleteKeyword(item: KeywordEntity)

    @Query("SELECT * FROM comment_templates ORDER BY sortOrder, id") fun observeComments(): Flow<List<CommentTemplateEntity>>
    @Query("SELECT * FROM comment_templates WHERE enabled=1 ORDER BY sortOrder, id") suspend fun getEnabledComments(): List<CommentTemplateEntity>
    @Insert suspend fun insertComment(item: CommentTemplateEntity)
    @Update suspend fun updateComment(item: CommentTemplateEntity)
    @Delete suspend fun deleteComment(item: CommentTemplateEntity)

    @Query("SELECT * FROM post_history ORDER BY processedAt DESC LIMIT 500") fun observeHistory(): Flow<List<PostHistoryEntity>>
    @Insert suspend fun insertHistory(item: PostHistoryEntity)
    @Query("SELECT * FROM post_history WHERE postUniqueId=:id ORDER BY processedAt DESC LIMIT 1") suspend fun latestHistory(id: String): PostHistoryEntity?

    @Query("SELECT * FROM app_logs ORDER BY timestamp DESC LIMIT 1000") fun observeLogs(): Flow<List<AppLogEntity>>
    @Insert suspend fun insertLog(item: AppLogEntity)

    @Query("SELECT * FROM daily_stats WHERE date=:date") suspend fun getDailyStats(date: String): DailyStatsEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertDailyStats(item: DailyStatsEntity)
}
