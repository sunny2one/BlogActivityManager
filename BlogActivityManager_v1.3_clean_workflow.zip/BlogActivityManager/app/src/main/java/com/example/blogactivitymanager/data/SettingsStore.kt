package com.example.blogactivitymanager.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("settings")

data class AppSettings(
    val likeEnabled: Boolean = true,
    val commentEnabled: Boolean = true,
    val commentMode: String = "SEQUENTIAL",
    val minSeconds: Int = 120,
    val maxSeconds: Int = 180,
    val scheduleEnabled: Boolean = false,
    val startHour: Int = 9,
    val startMinute: Int = 0,
    val endHour: Int = 22,
    val endMinute: Int = 0,
    val enabledDays: Set<Int> = setOf(1,2,3,4,5,6,7),
    val dailyPostLimit: Int = 30,
    val dailyLikeLimit: Int = 30,
    val dailyCommentLimit: Int = 30,
    val restEnabled: Boolean = false,
    val restEvery: Int = 5,
    val restMinMinutes: Int = 3,
    val restMaxMinutes: Int = 7,
    val testMode: Boolean = false,
    val keepScreenOn: Boolean = true,
    val autoLaunchNaver: Boolean = true,
    val errorAction: String = "PAUSE",
    val currentKeywordIndex: Int = 0,
    val currentCommentIndex: Int = 0
)

class SettingsStore(private val context: Context) {
    private object K {
        val LIKE = booleanPreferencesKey("like")
        val COMMENT = booleanPreferencesKey("comment")
        val COMMENT_MODE = stringPreferencesKey("comment_mode")
        val MIN = intPreferencesKey("min_seconds")
        val MAX = intPreferencesKey("max_seconds")
        val SCHEDULE = booleanPreferencesKey("schedule")
        val START_H = intPreferencesKey("start_h")
        val START_M = intPreferencesKey("start_m")
        val END_H = intPreferencesKey("end_h")
        val END_M = intPreferencesKey("end_m")
        val DAYS = stringPreferencesKey("days")
        val POST_LIMIT = intPreferencesKey("post_limit")
        val LIKE_LIMIT = intPreferencesKey("like_limit")
        val COMMENT_LIMIT = intPreferencesKey("comment_limit")
        val REST = booleanPreferencesKey("rest")
        val REST_EVERY = intPreferencesKey("rest_every")
        val REST_MIN = intPreferencesKey("rest_min")
        val REST_MAX = intPreferencesKey("rest_max")
        val TEST = booleanPreferencesKey("test")
        val SCREEN = booleanPreferencesKey("screen")
        val AUTO_LAUNCH = booleanPreferencesKey("auto_launch")
        val ERROR = stringPreferencesKey("error_action")
        val KEYWORD_INDEX = intPreferencesKey("keyword_index")
        val COMMENT_INDEX = intPreferencesKey("comment_index")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            likeEnabled = p[K.LIKE] ?: true,
            commentEnabled = p[K.COMMENT] ?: true,
            commentMode = p[K.COMMENT_MODE] ?: "SEQUENTIAL",
            minSeconds = p[K.MIN] ?: 120,
            maxSeconds = p[K.MAX] ?: 180,
            scheduleEnabled = p[K.SCHEDULE] ?: false,
            startHour = p[K.START_H] ?: 9,
            startMinute = p[K.START_M] ?: 0,
            endHour = p[K.END_H] ?: 22,
            endMinute = p[K.END_M] ?: 0,
            enabledDays = (p[K.DAYS] ?: "1,2,3,4,5,6,7").split(',').mapNotNull { it.toIntOrNull() }.toSet(),
            dailyPostLimit = p[K.POST_LIMIT] ?: 30,
            dailyLikeLimit = p[K.LIKE_LIMIT] ?: 30,
            dailyCommentLimit = p[K.COMMENT_LIMIT] ?: 30,
            restEnabled = p[K.REST] ?: false,
            restEvery = p[K.REST_EVERY] ?: 5,
            restMinMinutes = p[K.REST_MIN] ?: 3,
            restMaxMinutes = p[K.REST_MAX] ?: 7,
            testMode = p[K.TEST] ?: false,
            keepScreenOn = p[K.SCREEN] ?: true,
            autoLaunchNaver = p[K.AUTO_LAUNCH] ?: true,
            errorAction = p[K.ERROR] ?: "PAUSE",
            currentKeywordIndex = p[K.KEYWORD_INDEX] ?: 0,
            currentCommentIndex = p[K.COMMENT_INDEX] ?: 0
        )
    }

    suspend fun save(s: AppSettings) = context.dataStore.edit { p ->
        p[K.LIKE] = s.likeEnabled
        p[K.COMMENT] = s.commentEnabled
        p[K.COMMENT_MODE] = s.commentMode
        p[K.MIN] = s.minSeconds.coerceAtLeast(30)
        p[K.MAX] = s.maxSeconds.coerceAtLeast(s.minSeconds)
        p[K.SCHEDULE] = s.scheduleEnabled
        p[K.START_H] = s.startHour.coerceIn(0,23)
        p[K.START_M] = s.startMinute.coerceIn(0,59)
        p[K.END_H] = s.endHour.coerceIn(0,23)
        p[K.END_M] = s.endMinute.coerceIn(0,59)
        p[K.DAYS] = s.enabledDays.sorted().joinToString(",")
        p[K.POST_LIMIT] = s.dailyPostLimit.coerceAtLeast(1)
        p[K.LIKE_LIMIT] = s.dailyLikeLimit.coerceAtLeast(0)
        p[K.COMMENT_LIMIT] = s.dailyCommentLimit.coerceAtLeast(0)
        p[K.REST] = s.restEnabled
        p[K.REST_EVERY] = s.restEvery.coerceAtLeast(1)
        p[K.REST_MIN] = s.restMinMinutes.coerceAtLeast(1)
        p[K.REST_MAX] = s.restMaxMinutes.coerceAtLeast(s.restMinMinutes)
        p[K.TEST] = s.testMode
        p[K.SCREEN] = s.keepScreenOn
        p[K.AUTO_LAUNCH] = s.autoLaunchNaver
        p[K.ERROR] = s.errorAction
        p[K.KEYWORD_INDEX] = s.currentKeywordIndex.coerceAtLeast(0)
        p[K.COMMENT_INDEX] = s.currentCommentIndex.coerceAtLeast(0)
    }
}
