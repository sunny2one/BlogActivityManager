package com.example.blogactivitymanager.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.example.blogactivitymanager.MainActivity
import com.example.blogactivitymanager.data.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AutomationForegroundService : Service() {
    companion object {
        const val ACTION_START = "start"
        const val ACTION_TEST_START = "test_start"
        const val ACTION_PAUSE = "pause"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "automation"
        private const val ID = 1001
        private const val EXTRA_REASON = "reason"

        fun send(context: Context, action: String) {
            val i = Intent(context, AutomationForegroundService::class.java).setAction(action)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        fun stop(context: Context, reason: String) {
            val i = Intent(context, AutomationForegroundService::class.java)
                .setAction(ACTION_STOP)
                .putExtra(EXTRA_REASON, reason)
            context.startService(i)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var wakeLock: PowerManager.WakeLock? = null
    private var notificationJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "작업 상태", NotificationManager.IMPORTANCE_LOW))
        }
        notificationJob = scope.launch {
            AutomationState.state.collectLatest { state ->
                if (state.running) {
                    getSystemService(NotificationManager::class.java).notify(ID, notification())
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START, ACTION_TEST_START -> {
                // Android가 요구하는 시간 안에 Foreground 상태로 먼저 전환합니다.
                startForeground(ID, notification("시작 준비 중"))
                val requestedAction = intent.action
                scope.launch {
                    val settings = SettingsStore(this@AutomationForegroundService).settings.first()
                    AutomationState.stopRequested = false
                    AutomationState.pauseRequested = false
                    AutomationState.finishCurrentThenStop = false
                    AutomationState.testRunOverride = requestedAction == ACTION_TEST_START
                    AutomationState.state.value = AutomationState.state.value.copy(
                        running = true,
                        paused = false,
                        status = if (AutomationState.testRunOverride) "테스트 시작됨" else "시작됨"
                    )
                    updateWakeLock(settings.keepScreenOn)
                    if (settings.autoLaunchNaver) launchNaver()
                    if (settings.scheduleEnabled) {
                        ScheduleAlarmReceiver.scheduleNext(this@AutomationForegroundService, settings.startHour, settings.startMinute, settings.enabledDays)
                    }
                }
            }
            ACTION_PAUSE -> {
                AutomationState.pauseRequested = !AutomationState.pauseRequested
                AutomationState.state.value = AutomationState.state.value.copy(
                    paused = AutomationState.pauseRequested,
                    status = if (AutomationState.pauseRequested) "일시정지" else "재개"
                )
                if (AutomationState.pauseRequested) {
                    updateWakeLock(false)
                } else {
                    scope.launch {
                        val settings = SettingsStore(this@AutomationForegroundService).settings.first()
                        updateWakeLock(settings.keepScreenOn)
                    }
                }
                getSystemService(NotificationManager::class.java).notify(ID, notification())
            }
            ACTION_STOP -> stopServiceNow(intent.getStringExtra(EXTRA_REASON) ?: "사용자 중지")
        }
        return START_STICKY
    }

    private fun notification(overrideText: String? = null): Notification {
        val s = AutomationState.state.value
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val pause = PendingIntent.getService(this, 1, Intent(this, javaClass).setAction(ACTION_PAUSE), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, javaClass).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val text = overrideText ?: "${s.currentKeyword.ifBlank { "대기" }} · 오늘 ${s.todayProcessed}/${s.todayGoal.coerceAtLeast(0)}"
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Blog Activity Manager 실행 중")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(open)
            .addAction(0, "일시정지/재개", pause)
            .addAction(0, "중지", stop)
            .setOngoing(true)
            .build()
    }

    private fun launchNaver() {
        packageManager.getLaunchIntentForPackage(NaverNodeTexts.NAVER_BLOG_PACKAGE)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(it)
        }
    }

    private fun updateWakeLock(enabled: Boolean) {
        if (!enabled) {
            wakeLock?.takeIf { it.isHeld }?.release()
            wakeLock = null
            return
        }
        if (wakeLock?.isHeld == true) return
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:automation")
            .apply { acquire(6 * 60 * 60 * 1000L) }
    }

    private fun stopServiceNow(reason: String) {
        AutomationState.stopRequested = true
        AutomationState.testRunOverride = false
        AutomationState.state.value = AutomationState.state.value.copy(running = false, status = reason)
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        notificationJob?.cancel()
        wakeLock?.takeIf { it.isHeld }?.release()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
