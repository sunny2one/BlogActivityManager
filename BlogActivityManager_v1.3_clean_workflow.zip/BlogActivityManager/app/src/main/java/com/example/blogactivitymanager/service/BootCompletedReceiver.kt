package com.example.blogactivitymanager.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.blogactivitymanager.data.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED && intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val s = SettingsStore(context).settings.first()
                if (s.scheduleEnabled) ScheduleAlarmReceiver.scheduleNext(context, s.startHour, s.startMinute, s.enabledDays)
            } finally {
                pending.finish()
            }
        }
    }
}
