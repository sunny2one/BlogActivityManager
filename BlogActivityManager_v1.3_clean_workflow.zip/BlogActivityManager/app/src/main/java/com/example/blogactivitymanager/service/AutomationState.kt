package com.example.blogactivitymanager.service

import kotlinx.coroutines.flow.MutableStateFlow

data class RuntimeState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val status: String = "대기 중",
    val currentKeyword: String = "",
    val currentPostTitle: String = "",
    val currentBlogName: String = "",
    val currentStep: String = "",
    val elapsedSeconds: Int = 0,
    val remainingSeconds: Int = 0,
    val todayProcessed: Int = 0,
    val todayGoal: Int = 0,
    val likeSuccess: Int = 0,
    val commentSuccess: Int = 0,
    val skipped: Int = 0,
    val errors: Int = 0,
    val nextRestIn: Int = 0
)

object AutomationState {
    val state = MutableStateFlow(RuntimeState())
    @Volatile var stopRequested = false
    @Volatile var pauseRequested = false
    @Volatile var finishCurrentThenStop = false
    @Volatile var testRunOverride = false
}
